"use client";

import { useMoney } from "@/i18n/hooks";
import { useTranslations, type NamespaceKeys } from "next-intl";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import QRCode from "react-qr-code";
import { orpc } from "@/lib/orpc/query";
import SpinnerLoader from "@/components/Loader/SpinnerLoader";

type BookingStatusMessageKey = NamespaceKeys<"Enums", "bookingStatus">;
export function BookingConfirmationClient({ bookingId }: { bookingId: string }) {
    const router = useRouter();
    const t = useTranslations("BookingConfirmation");
    const tStatus = useTranslations("Enums.bookingStatus");
    const formatMoney = useMoney();
    const { data, isLoading } = useQuery(orpc.bookings.findOne.queryOptions({ input: { id: bookingId } }));
    const currentBooking = data?.data;

    if (isLoading || !currentBooking) {
        return <SpinnerLoader />;
    }

    return (
        <div className="max-w-4xl mx-auto px-4 py-8">
            <div className="bg-white rounded-lg shadow-lg p-8">
                <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                        <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">{t("title")}</h1>
                    <p className="text-gray-600">{t("sentTo", { email: currentBooking.email })}</p>
                </div>

                <div className="border-t border-b py-6 mb-6">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <span className="text-gray-500">{t("bookingId")}</span>
                            <p className="font-semibold">{currentBooking.id}</p>
                        </div>
                        <div>
                            <span className="text-gray-500">{t("status")}</span>
                            <p className="font-semibold text-green-600">
                                {tStatus(currentBooking.status as BookingStatusMessageKey)}
                            </p>
                        </div>
                        <div>
                            <span className="text-gray-500">{t("name")}</span>
                            <p className="font-semibold">
                                {currentBooking.firstName} {currentBooking.lastName}
                            </p>
                        </div>
                        <div>
                            <span className="text-gray-500">{t("tickets")}</span>
                            <p className="font-semibold">{currentBooking.quantity}</p>
                        </div>
                        <div>
                            <span className="text-gray-500">{t("totalPaid")}</span>
                            <p className="font-semibold text-indigo-600">
                                {formatMoney(currentBooking.finalAmount, currentBooking.currency)}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="space-y-6">
                    <h2 className="text-2xl font-bold text-gray-900">{t("yourTickets")}</h2>

                    {currentBooking.tickets?.map((ticket, index) => (
                        <div key={ticket.id} className="border rounded-lg p-6 bg-gray-50">
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <h3 className="font-semibold text-lg">
                                        {t("ticketNumber", { number: index + 1 })}
                                    </h3>
                                    <p className="text-sm text-gray-600">{ticket.ticketNumber}</p>
                                </div>
                                {ticket.isValidated && (
                                    <span className="bg-red-100 text-red-800 text-xs font-semibold px-2.5 py-0.5 rounded">
                                        {t("used")}
                                    </span>
                                )}
                            </div>

                            <div className="flex justify-center bg-white p-4 rounded">
                                <QRCode value={ticket.qrCode} size={200} />
                            </div>

                            <p className="text-center text-sm text-gray-500 mt-4">{t("presentQr")}</p>
                        </div>
                    ))}
                </div>

                <div className="mt-8 flex gap-4">
                    <button
                        onClick={() => router.push("/")}
                        className="flex-1 bg-indigo-600 text-white py-3 px-6 rounded-md hover:bg-indigo-700 transition-colors font-semibold"
                    >
                        {t("browseMore")}
                    </button>
                    <button
                        onClick={() => window.print()}
                        className="flex-1 bg-gray-200 text-gray-700 py-3 px-6 rounded-md hover:bg-gray-300 transition-colors font-semibold"
                    >
                        {t("print")}
                    </button>
                </div>
            </div>
        </div>
    );
}
